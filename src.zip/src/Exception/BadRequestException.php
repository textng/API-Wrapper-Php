<?php

namespace Elmage\TextNg\Exception;

class BadRequestException extends HttpException
{
}
