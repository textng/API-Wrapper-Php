<?php

namespace Elmage\TextNg\Exception;

class ExpiredTokenException extends UnauthorizedException
{
}
