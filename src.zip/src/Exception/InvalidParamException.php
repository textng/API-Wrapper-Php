<?php

namespace Elmage\TextNg\Exception;

class InvalidParamException extends RuntimeException
{
}
