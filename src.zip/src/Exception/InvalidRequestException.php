<?php

namespace Elmage\TextNg\Exception;

class InvalidRequestException extends BadRequestException
{
}
