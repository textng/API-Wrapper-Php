<?php

namespace Elmage\TextNg\Exception;

class ServiceUnavailableException extends HttpException
{
}
