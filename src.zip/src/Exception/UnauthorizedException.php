<?php

namespace Elmage\TextNg\Exception;

class UnauthorizedException extends HttpException
{
}
