<?php

namespace Elmage\TextNg\Exception;

class RuntimeException extends \RuntimeException implements Exception
{
}
