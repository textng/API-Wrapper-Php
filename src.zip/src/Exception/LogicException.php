<?php

namespace Elmage\TextNg\Exception;

class LogicException extends \LogicException implements Exception
{
}
