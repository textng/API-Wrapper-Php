<?php

namespace Elmage\TextNg\Exception;

interface Exception
{
}
