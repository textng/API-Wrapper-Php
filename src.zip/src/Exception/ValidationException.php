<?php

namespace Elmage\TextNg\Exception;

class ValidationException extends HttpException
{
}
