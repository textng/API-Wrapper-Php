<?php

namespace Elmage\TextNg\Exception;

class InternalServerException extends HttpException
{
}
