<?php

namespace Elmage\TextNg\Exception;

class NotFoundException extends HttpException
{
}
