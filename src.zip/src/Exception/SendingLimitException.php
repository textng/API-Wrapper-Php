<?php

namespace Elmage\TextNg\Exception;

class SendingLimitException extends RuntimeException
{
}
