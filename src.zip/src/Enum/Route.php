<?php

namespace Elmage\TextNg\Enum;

class Route
{
    const CORPORATE = 3;
    const CORPORATE_BYPASS = 4;
    const RECOMMENDED = 5;
    const STANDARD = 6;

    public static array $routes = array(3, 4, 5, 6);
}
