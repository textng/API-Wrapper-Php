<?php

namespace Elmage\TextNg\Enum;

class DeliveryReportReq
{
    const ALL = 'all';
    const DND = 'dnd';
    const SUCCESS = 'success';
}
